Worth It? V4（夢幻暖色＋促銷資訊）

1. 在 GitHub 的 margasananda/worth-it-app 更新根目錄 index.html，檔名必須是 index.html。
2. 若要啟用自動搜尋和促銷標示：請在 Cloudflare Workers 更新 worker.js，並於 Settings / Variables and Secrets 安全設定 SERPAPI_KEY（不要放進 GitHub）。
3. 在 App 的「初次使用：設定搜尋服務」填入 https:// 開頭的 Worker 公開網址並儲存。
4. 只有搜尋供應商回傳可辨識原價／特價或明確折扣資訊時才會顯示「查看特價促銷」。無資料不會假造促銷或銷量。
5. 前六名排名仍根據公開彙總評分和評論數，僅比對有限的搜尋結果；非全網最低價保證。
6. 修改後請在 iPhone Safari 重新整理網站。
